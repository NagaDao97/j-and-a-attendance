// service-worker.js

self.addEventListener('install', (event) => {
  console.log('Service Worker Installed');
  event.waitUntil(
    caches.open('my-cache').then((cache) => {
      return cache.addAll([
        '/',              // Home page
        '/index.html',    // Your main HTML file
        '/style.css',     // Your CSS file
        '/app.js',        // Your main JavaScript file
        '/icon.png',      // Your app icon
      ]);
    })
  );
});

self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});
